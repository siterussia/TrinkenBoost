package com.trikenbooster.app

import android.app.Activity
import android.os.Bundle
import android.os.BatteryManager
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.WindowManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 13, 22)
        window.navigationBarColor = android.graphics.Color.rgb(9, 13, 22)
        window.decorView.systemUiVisibility = 0
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(DeviceBridge(this), "AndroidDevice")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    class DeviceBridge(private val activity: Activity) {
        @JavascriptInterface fun model(): String = "${Build.MANUFACTURER} ${Build.MODEL}"
        @JavascriptInterface fun androidVersion(): String = Build.VERSION.RELEASE ?: "unknown"
        @JavascriptInterface fun batteryPercent(): Int {
            val manager = activity.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            return manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        }
        @JavascriptInterface fun vibrate() {
            val vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") vibrator.vibrate(35)
        }
    }
}
